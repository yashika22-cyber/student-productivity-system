const form = document.getElementById("taskForm");
const titleInput = document.getElementById("title");
const subjectInput = document.getElementById("subject");
const deadlineInput = document.getElementById("deadline");
const priorityInput = document.getElementById("priority");
const taskList = document.getElementById("taskList");
const searchInput = document.getElementById("search");
const filterInput = document.getElementById("filter");

let tasks = [];

try {
    tasks = JSON.parse(localStorage.getItem("studyTasks") || "[]");

    if (!Array.isArray(tasks)) {
        tasks = [];
    }
} catch (error) {
    tasks = [];
}

function saveTasks() {
    localStorage.setItem("studyTasks", JSON.stringify(tasks));
}

function isOverdue(task) {
    if (task.completed) return false;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return new Date(task.deadline + "T00:00:00") < today;
}

function updateDashboard() {
    const completed = tasks.filter(task => task.completed).length;
    const pending = tasks.filter(task => !task.completed).length;
    const overdue = tasks.filter(task => isOverdue(task)).length;

    const percent = tasks.length
        ? Math.round((completed / tasks.length) * 100)
        : 0;

    document.getElementById("total").textContent = tasks.length;
    document.getElementById("completed").textContent = completed;
    document.getElementById("pending").textContent = pending;
    document.getElementById("overdue").textContent = overdue;
    document.getElementById("percent").textContent = percent + "%";
    document.getElementById("bar").style.width = percent + "%";
}

function renderTasks() {
    taskList.replaceChildren();

    const query = searchInput.value.trim().toLowerCase();
    const filter = filterInput.value;

    const visibleTasks = tasks.filter(task => {
        const matchesSearch =
            task.title.toLowerCase().includes(query) ||
            task.subject.toLowerCase().includes(query);

        let matchesFilter = true;

        if (filter === "Completed") {
            matchesFilter = task.completed;
        } else if (filter === "Pending") {
            matchesFilter = !task.completed && !isOverdue(task);
        } else if (filter === "Overdue") {
            matchesFilter = isOverdue(task);
        }

        return matchesSearch && matchesFilter;
    });

    if (visibleTasks.length === 0) {
        const message = document.createElement("p");
        message.className = "empty-message";
        message.textContent = tasks.length
            ? "No matching tasks found."
            : "📚 No tasks yet. Add your first study task!";
        taskList.appendChild(message);
    }

    visibleTasks.forEach(task => {
        const card = document.createElement("article");
        card.className = "task" + (task.completed ? " done" : "");

        const heading = document.createElement("h3");
        heading.textContent = task.title;

        const subject = document.createElement("p");
        subject.textContent = "📘 Subject: " + task.subject;

        const deadline = document.createElement("p");
        deadline.textContent = "📅 Deadline: " + task.deadline;

        const priority = document.createElement("span");
        priority.className = "priority-label priority-" +
            task.priority.toLowerCase();
        priority.textContent = task.priority + " Priority";

        const status = document.createElement("p");
        status.className = "status";

        if (task.completed) {
            status.textContent = "✅ Completed";
            status.classList.add("status-completed");
        } else if (isOverdue(task)) {
            status.textContent = "⚠️ Overdue";
            status.classList.add("status-overdue");
        } else {
            status.textContent = "⏳ Pending";
        }

        const actions = document.createElement("div");
        actions.className = "task-actions";

        const completeButton = document.createElement("button");
        completeButton.type = "button";
        completeButton.textContent = task.completed
            ? "↩ Undo"
            : "✓ Complete";

        completeButton.addEventListener("click", () => {
            task.completed = !task.completed;
            saveTasks();
            renderTasks();
        });

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.textContent = "🗑 Delete";
        deleteButton.className = "delete-btn";

        deleteButton.addEventListener("click", () => {
            tasks = tasks.filter(item => item.id !== task.id);
            saveTasks();
            renderTasks();
        });

        actions.append(completeButton, deleteButton);
        card.append(
            heading,
            subject,
            deadline,
            priority,
            status,
            actions
        );

        taskList.appendChild(card);
    });

    updateDashboard();
}

form.addEventListener("submit", event => {
    event.preventDefault();

    const title = titleInput.value.trim();
    const deadline = deadlineInput.value;

    if (!title || !deadline || !subjectInput.value) {
        alert("Please fill in all required fields.");
        return;
    }

    tasks.push({
        id: Date.now() + Math.random(),
        title: title,
        subject: subjectInput.value,
        deadline: deadline,
        priority: priorityInput.value,
        completed: false
    });

    saveTasks();
    form.reset();

    renderTasks();
});

searchInput.addEventListener("input", renderTasks);
filterInput.addEventListener("change", renderTasks);

renderTasks();